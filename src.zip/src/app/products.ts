export interface productInterface
{
    
login: string
id: number
avatar_url: string
url:string
}
export class product{
    OrderName!:string
    Price!:string
    Quantity!: string
}